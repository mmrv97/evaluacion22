package com.gestion.parqueadero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionEmpleadosParqueaderoBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionEmpleadosParqueaderoBackendApplication.class, args);
	}

}
