package com.registro.usuarios.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.registro.usuarios.servicio.UsuarioServicio;

@Controller
public class ParqueaderoControlador {

    @Autowired
    private ParqueaderoServicio parqueaderoServicio;

    @GetMapping("/parqueadero")
    public String listarEntradas(Model modelo) {
        // Aquí debes recuperar y mostrar las entradas de vehículos en el parqueadero
        List<EntradaVehiculo> entradas = parqueaderoServicio.listarEntradas();
        modelo.addAttribute("entradas", entradas);
        return "listaEntradas"; // Crea una vista para mostrar la lista de entradas
    }

    @GetMapping("/parqueadero/registro")
    public String mostrarFormularioRegistro(Model modelo) {
        // Aquí debes mostrar un formulario para registrar nuevas entradas de vehículos
        modelo.addAttribute("nuevaEntrada", new EntradaVehiculo());
        return "formularioRegistro"; // Crea una vista con el formulario de registro
    }

    @PostMapping("/parqueadero/registro")
    public String registrarEntrada(@ModelAttribute EntradaVehiculo nuevaEntrada) {
        // Aquí debes procesar el registro de una nueva entrada de vehículo
        parqueaderoServicio.registrarEntrada(nuevaEntrada);
        return "redirect:/parqueadero"; // Redirige a la lista de entradas
    }

    @GetMapping("/parqueadero/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model modelo) {
        // Aquí debes mostrar un formulario para editar una entrada de vehículo existente
        EntradaVehiculo entrada = parqueaderoServicio.obtenerEntradaPorId(id);
        modelo.addAttribute("entrada", entrada);
        return "formularioEdicion"; // Crea una vista con el formulario de edición
    }

    @PostMapping("/parqueadero/editar/{id}")
    public String editarEntrada(@PathVariable Long id, @ModelAttribute EntradaVehiculo entrada) {
        // Aquí debes procesar la edición de una entrada de vehículo
        parqueaderoServicio.actualizarEntrada(id, entrada);
        return "redirect:/parqueadero"; // Redirige a la lista de entradas
    }

    @GetMapping("/parqueadero/eliminar/{id}")
    public String eliminarEntrada(@PathVariable Long id) {
        // Aquí debes eliminar una entrada de vehículo
        parqueaderoServicio.eliminarEntrada(id);
        return "redirect:/parqueadero"; // Redirige a la lista de entradas
    }
}
